import UIKit

// MARK: - ARRAYS
// 1. Stores ordered values of one type
var array = [String]()
array = ["Mike", "Barry", "Lorey", "Sally"]
print(array)

// 2. Efficient at using zero-index to show value at a specific index in the array
// Uses 0(1) - constant time since array is in order
print(array[1])

// 3. INefficient at searching for a student's grade based on their name
// Uses O(n) - linear time
var students: [Student] = [
    Student(name: "Mike", grade: "A"),
    Student(name: "Todd", grade: "B"),
    Student(name: "Bob", grade: "C")
]

for i in students {
    if i.name == "Todd" {
        print(i.grade)
        break
    }
}



// MARK: - DICTIONARY
// 1. Stores unordered key value pairs, where dictionary values can be accessed using their key identifier
var dictionary = [String: String]()
dictionary = [
    "Mike": "A", "Barry": "B",
    "Lorey": "C", "Sally": "A"
]

// 2. Efficient at fast data retrieval
// Uses key to find its value in the dictionary quickly O(1)
print(dictionary["Mike"])
print(dictionary["Bob", default: "Unknown"])



// MARK: - HOW TO ADD FUNCTIONALITY TO STRUCT
struct Student {
    var name, grade: String
}

extension Student {
    func printGrade() {
        print(grade)
    }
}

struct StudentInfo {
    var student: Student
    var location: String
}



// MARK: - SETS
// 1. Stores unordered, unique values of one type
var set = Set<String>()
set = ["Todd", "Mike", "Todd", "Bob"]

// 2. Removes duplicates
print(set) // only prints 3 students bc it doesn't contain duplicates

// 3. Can quickly find if set contains a value using O(1)
var bob = set.contains("Bob")



// MARK: - ENUM
// 1. Data type that stores a group of related values (using cases)
enum Seasons {
    case Summer
    case Winter
    case Spring
    case Fall
}

// 2. Allows you to work with cases/values in a type-safe way
print(Seasons.Fall)

// Not type-safe bc seasons1-4 are not related in code
var season1 = "Summer"
var season2 = "summer"
var season3 = "Winter"
var season4 = "Fall"

// 3. Enum-associated values, used as coding keys
// Used to handle differences between JSON keys and Codable struct's property names
// Ex: Handles converting JSON keys (often in snake_case) into Swift  property names (in camelCase)
struct SeasonalSales: Codable {
    let summerSale, winterSale, fallSale, springSale: [String]
    
    enum CodingKeys: String, CodingKey {
        case summerSale = "summer_sale"
        case winterSale = "winter_sale"
        case fallSale = "fall_sale"
        case springSale = "spring_sale"
    }
}

